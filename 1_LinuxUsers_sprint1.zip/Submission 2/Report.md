
Group Number: 1
Group Name: LinuxUsers
Student IDs:
- Rafal Kucharski: 22706241
- Tamoghni Banerjee:  22205922
- Alice Karatchentzeff de Vienne: 22707181

GitHub Link: https://github.com/Juutar/COMP20050SEP2-1.git*

All members contributed equally.