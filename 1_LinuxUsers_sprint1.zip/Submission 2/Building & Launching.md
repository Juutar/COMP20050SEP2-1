
JDK used: openjdk-21
Launching: run the jar file
Playing: 
- click on the hexagons to place atoms (max 6)
- click on the "show true atoms" to show/hide the randomly placed true atoms
- click on the "set rays" to see/hide the ray pointers (this function disables the atom placement)
